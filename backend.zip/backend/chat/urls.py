from django.urls import path
from . import views

urlpatterns = [

    # path("my-messages/", views.MyInbox.as_view()),
    # path("get-messages/<reciever_id>/", views.GetMessages.as_view()),
    # path("send-messages/", views.SendMessages.as_view()),
]